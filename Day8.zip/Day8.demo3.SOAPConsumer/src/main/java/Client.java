import demo.Hello;
import demo.My;

public class Client {
    public static void main(String[] args) {
        My myinstance = new My();
        Hello porttype = myinstance.getHelloPort();
        String str =  porttype.greet("Vaishali....");
        System.out.println("Server Returned  " + str);
    }
}
