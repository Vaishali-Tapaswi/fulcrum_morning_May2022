package demo1;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import demo.Emp;
import demo.Hello;
import demo.My;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/first")
public class FirstController {
	@GetMapping(value = "/{min}/{max}")
	public List<Emp> m1(@PathVariable(name = "min") int min, @PathVariable(name="max") int max){
		String str = "Get in m1 - FirstController " + new Date();
		List<Emp> list =new ArrayList<>();
		My service = new My();
		Hello porttype = service.getHelloPort();

		for (int i = min; i<= max ;i++){
			Emp e= porttype.getemp(i);
			list.add(e);

		}
		return list;
	}

}

