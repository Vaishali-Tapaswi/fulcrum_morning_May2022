package  demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.Expression;
import org.springframework.expression.common.LiteralExpression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.http.outbound.HttpRequestExecutingMessageHandler;
import org.springframework.integration.stream.CharacterStreamReadingMessageSource;
import org.springframework.integration.stream.CharacterStreamWritingMessageHandler;
import org.springframework.integration.transformer.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.support.MessageBuilder;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class MyConfig {
    @Bean
    public MessageChannel strchannel(){
        return new DirectChannel();
    }
    @Bean
    public MessageChannel httpresp(){
        return new DirectChannel();
    }
    @Bean
    @InboundChannelAdapter(channel = "strchannel",poller = @Poller(fixedRate = "500"))
    public MessageSource<String> streamReading() {
        CharacterStreamReadingMessageSource sourceReader = new CharacterStreamReadingMessageSource(
                new InputStreamReader(System.in));
        sourceReader.receive();
        return sourceReader;
    }


    @Bean
    @ServiceActivator(inputChannel = "strchannel")
    public MessageHandler gethttpdata() {
        String url = "http://localhost:8085/pv/hello/{var11}";
        HttpRequestExecutingMessageHandler handler = new HttpRequestExecutingMessageHandler(url);

        // Static Parameter
        handler.setUriVariableExpressions(Collections.singletonMap("var11",new LiteralExpression("aaa")));
        // Dynamic Parameter
        SpelExpressionParser parser = new SpelExpressionParser();
        handler.setUriVariableExpressions(Collections.singletonMap("var11", parser.parseExpression("payload")));

        handler.setHttpMethod(HttpMethod.GET);
        handler.setRequiresReply(true);
        handler.setExpectedResponseType(String.class);
        handler.setOutputChannelName("httpresp");
        return handler;
    }
    @Bean
    @ServiceActivator(inputChannel = "trasformoutput")
    public MessageHandler streamWriting2() {
        CharacterStreamWritingMessageHandler handler = new CharacterStreamWritingMessageHandler(
                new OutputStreamWriter(System.err));
        return handler;
    }
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "httpresp", outputChannel = "trasformoutput")
    public Transformer tranform(){
        //return  new MyTransformer();
        return  (message)-> {
            System.out.println("in tranform " + message.getPayload());
            Message<String> outmessage =
                    MessageBuilder.createMessage(message.getPayload().toString(), message.getHeaders());
            return outmessage;
        };
    }

}
