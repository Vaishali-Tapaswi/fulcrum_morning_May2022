package demo;

import controllers.EmpController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "controllers")
@EntityScan(basePackages = "entities")
@EnableJpaRepositories(basePackages = "repos")
public class Application {

    public static void main(String[] args) {
        ApplicationContext ctx = SpringApplication.run(Application.class, args);
        EmpController empc = ctx.getBean("empController", EmpController.class);
        empc.insert();
        empc.process();
    }

}