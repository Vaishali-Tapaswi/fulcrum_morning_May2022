package controllers;

import entities.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Controller;
import repos.EmpRepo;
@Controller
public class EmpController {

    @Autowired
    private EmpRepo repo;

    public void process(){
       repo.findAll().forEach(System.out::println);
        System.out.println("Show Record with Name ending with li");
        Emp emp = new Emp();
        emp.setEname("li");
        ExampleMatcher customExampleMatcher = ExampleMatcher.matchingAny()
                .withMatcher("ename", ExampleMatcher.GenericPropertyMatchers.endsWith().ignoreCase());

        Example<Emp> example = Example.of(emp, customExampleMatcher);
        repo.findAll(example).forEach(System.out::println);


        System.out.println("Show Record with Deparment as dept5");
        repo.findByDepartment("dept5").forEach(System.out::println);

        System.out.println("Show Record with Project as Proj2");
        repo.findByProject("Proj2").forEach(System.out::println);

        System.out.println("Show Record with Project as Proj3 and name as vaishali");
        repo.findBynameanddeparment("vaishali","Proj3").forEach(System.out::println);

    }



    public void insert(){
        String[] names = new String[] {"simran","simone","vaishali","sonali","vishal"};
        String[] projects = new String[] {"Proj1","Proj2","Proj3"};

        for (int i = 1;i< 21; i++){
            Emp e = new Emp();
            e.setEmpno("E"+i);
            e.setEname(names[i % names.length]);
            e.setProject(projects[i %projects.length]);
            e.setDepartment("dept" + (i % 6));
            e.setSalary((int)(Math.random()*1000));
            repo.save(e);
        }
    }
}
/*

   private  String empno;
   private  String ename;
    private   double salary ;// -> random number
    private   String project ;//-> proj1,proj2
    private   String department;//  (dept1,dept2,dept3


 */