package repos;

import entities.Emp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmpRepo extends JpaRepository<Emp,String> {
    List<Emp> findByProject(String project);
    List<Emp> findByDepartment(String department);

    @Query("select e from Emp e where  e.ename= ?1 and e.project=?2")
    List<Emp> findBynameanddeparment(String ename, String projname);
}
