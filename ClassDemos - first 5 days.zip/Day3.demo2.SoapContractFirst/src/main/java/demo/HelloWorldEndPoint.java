package demo;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

@Endpoint
public class HelloWorldEndPoint {
    private static final String NAMESPACE_URI = "http://demo/";

    private <T> JAXBElement<T> createJaxbElement(T object, Class<T> clazz) {
        return new JAXBElement<>(new QName(clazz.getSimpleName()), clazz, object);
    }


    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "helloRequest")
    public @ResponsePayload()
    JAXBElement<HelloResponse> hello(@RequestPayload HelloRequest request) {
        System.out.println("Hello" + request);
        HelloResponse resp = new HelloResponse();
        resp.setReturn("Hello from Spring Boot WebServices, "+ request.getArg0());
        return createJaxbElement(resp, HelloResponse.class);
        //return resp;
    }

}