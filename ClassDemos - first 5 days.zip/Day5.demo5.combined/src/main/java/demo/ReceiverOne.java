package demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ReceiverOne {

  @JmsListener(destination = "myqueue", containerFactory = "myFactory1")
  public void receiveMessage1(Email email) {
    System.out.println("ReceivedOne MyQueue <" + email + ">");
  }



  @JmsListener(destination = "mytopic", containerFactory = "myFactory2")
  public void receiveMessage2(Email email) {
    System.out.println("ReceivedOne MyTopic <" + email + ">");
  }




}