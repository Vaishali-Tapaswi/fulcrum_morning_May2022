package params;

import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value="/rp")
public class RequestParamDemo {

    @GetMapping(value="/hello")
    public String hello( @RequestParam(name = "nm") String name){
        System.out.println("RequestParamDemo - hello invoked with " + name);
        return "Hello, " + name;
    }
    @GetMapping(value="/add")
    public String add(@RequestParam(name="n1") int no1,@RequestParam(name="n2") int no2){
        System.out.println("RequestParamDemo - add invoked with " + no1 + " , " + no2);
        return "Sum = " + (no1+no2);
    }
}
