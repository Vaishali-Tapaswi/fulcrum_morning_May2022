package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import sun.java2d.pipe.SpanShapeRenderer;

@SpringBootApplication
public class Application {
	@Bean
	@Scope(value = "prototype")
	public First first(){
		System.out.println("in first method of Application class");
		return new First();
	}
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Application.class, args);
		System.out.println("----------------After Context loaded ------------------");
		Simple simple1 = context.getBean("simple", Simple.class);
		simple1.m1();
		Simple simple2 = context.getBean("simple", Simple.class);
		simple2.m1();
		Simple simple3 = context.getBean("simple", Simple.class);
		simple3.m1();

		First first1 = context.getBean("first", First.class);
		first1.m1();
		First first2 = context.getBean("first", First.class);
		first2.m1();

	}

}