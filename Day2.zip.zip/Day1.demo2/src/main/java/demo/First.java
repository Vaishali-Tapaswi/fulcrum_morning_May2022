package demo;

public class First {
    public  First(){
        System.out.println("in First Constructor...");
    }
    public void m1(){
        System.out.println("m1 of First");
    }
}
