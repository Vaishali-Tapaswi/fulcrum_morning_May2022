package demo;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Splitter;
import org.springframework.integration.json.JsonToObjectTransformer;
import org.springframework.integration.stream.CharacterStreamWritingMessageHandler;
import org.springframework.integration.transformer.ObjectToStringTransformer;
import org.springframework.integration.transformer.Transformer;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.FileReadingMessageSource;

import org.springframework.integration.file.FileWritingMessageHandler;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.io.File;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class MyConfig {
    final String inputdir = "C:\\tt\\inputdir";
    final String outputdir1 ="c:\\tt\\outputdir1";
    @Bean
    public MessageChannel readfile(){
         return new DirectChannel();
     }

    @Bean
    @InboundChannelAdapter(channel = "readfile",poller = @Poller(fixedRate = "500"))
    public MessageSource<File> streamReading() {
        FileReadingMessageSource sourceReader = new FileReadingMessageSource();
        sourceReader.setDirectory(new File(inputdir));
        return sourceReader;
    }

    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "readfile",outputChannel = "stringout")
    public  Transformer transform1(){
        return new FileToStringTransformer();
    }
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "stringout",outputChannel = "arraylistout")
    public  Transformer transform2(){
        return new JsonToObjectTransformer(ArrayList.class);
    }

    @Splitter(inputChannel = "arraylistout", outputChannel = "empout")
    List<Emp> extractItems(ArrayList arrayList) {
        return arrayList;
    }
    //ObjectToStringTransformer
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "empout",outputChannel = "empstring")
    public  Transformer transform3(){
        return new ObjectToStringTransformer();
    }

    @Bean
    @ServiceActivator(inputChannel = "empstring")
    public MessageHandler FileWriting1() {

        FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(outputdir1));

    //    handler.setFileExistsMode(FileExistsMode.);
        handler.setFileNameGenerator((msg)->msg.getHeaders().getId().toString() +".txt");
        handler.setExpectReply(false);
        return handler;
   /*         CharacterStreamWritingMessageHandler handler = new CharacterStreamWritingMessageHandler(
                    new OutputStreamWriter(System.err));
            handler.appendNewLine(true);
            return handler;

    */

    }
}
