package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/")
public class MyController {
    @GetMapping()
    public String index(){
        String str = "<h1><a href='admin/m1'>Admin m1 </a></h1>"+
                "<h1><a href='admin/m2'>Admin m2 </a></h1>"+
                "<h1><a href='simple'>Simple </a></h1>"+
                "<H1>Index.html</H1>";
        return str;
    }
    @GetMapping(value="/simple")
    public String simple(){
        String str = "<H1>Simple html</H1>" +
                        "<h1><a href='/'>Home Page</a></h1>";
        return str;
    }


    @GetMapping(value="/admin/m1")
    public String m1(){
        String str = "<H1>Admin m1 html</H1>" +
                "<h1><a href='/'>Home Page</a></h1>";
        return str;
    }

    @GetMapping(value="/admin/m2")
    public String m2(){
        String str = "<H1>Admin m2 html</H1>" +
                "<h1><a href='/'>Home Page</a></h1>";
        return str;
    }
}
