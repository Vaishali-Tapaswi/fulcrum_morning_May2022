package demo;

import controllers.DeptController;
import entities.Dept;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repos.DeptRepo;

@SpringBootApplication(scanBasePackages = "controllers")
@EntityScan( basePackages = "entities")
@EnableJpaRepositories(basePackages = "repos")
public class Application {
	/*@Bean
	public String simple(DeptRepo repo){
		System.out.println("in Simple ..." + repo);
		Dept d = new Dept();
		d.setDeptno(10);
		d.setDname("HR");
		d.setLoc("Hyd");
		repo.save(d);
		return "Success";
	}
	@Bean()
	@Scope(value="prototype")
	public String list(DeptRepo repo){
		System.out.println("in list ..." + repo);

		return "Success";
	}

*/
	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		DeptController controller = ctx.getBean("deptcontroller", DeptController.class);
		controller.process();
	}

}