package simple.demo.abc;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.Endpoint;
import java.util.Date;
@WebService(name = "Hello", serviceName = "My", targetNamespace = "http://demo")
public class SOAPProvider {
   @WebMethod(operationName = "greet")
   public String hello(@WebParam(name = "name") String name){
       System.out.println("Hello in SOAPProvider invoked " + new Date());
       return "Hello, " + name + " at " + new Date();
   }

    @WebMethod(operationName = "getemp")
    public Emp get(@WebParam(name = "empno") int empno){
        System.out.println("Employee get with "  + empno);
        Emp e = new Emp();
        e.setEmpno(empno);
        e.setEname("Nameof"+empno);
        e.setSalary(empno * 1000.1);
        return e;
    }


    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8080/hello", new SOAPProvider());
    }
}
