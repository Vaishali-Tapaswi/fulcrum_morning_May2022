package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Emp
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2022-05-19T06:11:26.198Z[GMT]")


public class Emp   {
  @JsonProperty("empno")
  private Integer empno = null;

  @JsonProperty("ename")
  private String ename = null;

  @JsonProperty("salary")
  private Double salary = null;

  public Emp empno(Integer empno) {
    this.empno = empno;
    return this;
  }

  /**
   * Get empno
   * @return empno
   **/
  @Schema(description = "")
  
    public Integer getEmpno() {
    return empno;
  }

  public void setEmpno(Integer empno) {
    this.empno = empno;
  }

  public Emp ename(String ename) {
    this.ename = ename;
    return this;
  }

  /**
   * Get ename
   * @return ename
   **/
  @Schema(description = "")
  
    public String getEname() {
    return ename;
  }

  public void setEname(String ename) {
    this.ename = ename;
  }

  public Emp salary(Double salary) {
    this.salary = salary;
    return this;
  }

  /**
   * Get salary
   * @return salary
   **/
  @Schema(description = "")
  
    public Double getSalary() {
    return salary;
  }

  public void setSalary(Double salary) {
    this.salary = salary;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Emp emp = (Emp) o;
    return Objects.equals(this.empno, emp.empno) &&
        Objects.equals(this.ename, emp.ename) &&
        Objects.equals(this.salary, emp.salary);
  }

  @Override
  public int hashCode() {
    return Objects.hash(empno, ename, salary);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Emp {\n");
    
    sb.append("    empno: ").append(toIndentedString(empno)).append("\n");
    sb.append("    ename: ").append(toIndentedString(ename)).append("\n");
    sb.append("    salary: ").append(toIndentedString(salary)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
