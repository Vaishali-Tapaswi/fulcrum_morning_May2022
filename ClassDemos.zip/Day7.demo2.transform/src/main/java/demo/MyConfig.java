package demo;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.stream.CharacterStreamReadingMessageSource;
import org.springframework.integration.stream.CharacterStreamWritingMessageHandler;
import org.springframework.integration.transformer.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.support.MessageBuilder;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

@Configuration
//@EnableIntegration
public class MyConfig {
    @Bean
    public MessageChannel inputdata(){
       return new DirectChannel();
    }
    @Bean
    public MessageChannel trasformoutput(){
        return new DirectChannel();
    }
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "inputdata", outputChannel = "trasformoutput")
    public Transformer tranform(){
        //return  new MyTransformer();
        return  (message)-> {
                System.out.println("in tranform " + message);
        Message<String> outmessage =
                MessageBuilder.createMessage(message.getPayload().toString().toUpperCase(), message.getHeaders());
        return outmessage;
    };
    }

    @Bean
    @InboundChannelAdapter(channel = "inputdata",poller = @Poller(fixedRate = "500"))
    public MessageSource<String> streamReading() {
        CharacterStreamReadingMessageSource sourceReader = new CharacterStreamReadingMessageSource(
                new InputStreamReader(System.in));
        return sourceReader;
    }
    @Bean
    @ServiceActivator(inputChannel = "trasformoutput")
    public MessageHandler streamWriting1() {
        CharacterStreamWritingMessageHandler handler = new CharacterStreamWritingMessageHandler(
                new OutputStreamWriter(System.out));
        return handler;
    }
}
