/*
package demo;


import org.springframework.integration.transformer.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.Locale;

public class MyTransformer implements Transformer {
    @Override
    public Message<?> transform(Message<> message) {
        System.out.println("in tranform " + message);
        Message<String> outmessage =
                MessageBuilder.createMessage(message.getPayload().toString().toUpperCase(Locale.ROOT), message.getHeaders());
        return outmessage;
    }
}
*/