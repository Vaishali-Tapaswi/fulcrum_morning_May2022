package demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "singleton")
@Lazy
// singleton(default) -single instance of class , prototype- new instance for getbean
public class Simple {
    public Simple(){
        System.out.println("in Simple Constructor");
    }
    public void m1(){
        System.out.println("m1 invoked ....");

    }
}
