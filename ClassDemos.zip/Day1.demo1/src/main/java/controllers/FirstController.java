package controllers;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/")
public class FirstController {
    @GetMapping
    public String method1() {
        String str = "GetMapping in method1";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }
    @PostMapping
    public String method2() {
        String str = "PostMapping in method2";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }
    @PutMapping
    public String method3() {
        String str = "PutMapping in method3";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }
    @DeleteMapping
    public String method4() {
        String str = "DeleteMapping in method4";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }

}


