package controllers;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/third")
public class ThirdController {
    @GetMapping(produces = MediaType.TEXT_PLAIN_VALUE)
    public String method1() {
        String str = "plain text in method1";
        System.out.println(str);
        return "plain text method1";
    }

    @GetMapping(produces = MediaType.TEXT_HTML_VALUE)
    public String method2() {
        String str = "html in method2";
        System.out.println(str);
        return "<h1>HTML Data " + str +"</h1>";
    }

}


