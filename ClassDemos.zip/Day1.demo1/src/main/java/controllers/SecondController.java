package controllers;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/second")
public class SecondController {
    @GetMapping(value="/s1")
    public String method1() {
        String str = "GetMapping in method1";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }
    @GetMapping(value="/s2")
    public String method2() {
        String str = "GetMapping in method2";
        System.out.println(str);
        return "<h1>" + str + "</h1>";
    }


}


