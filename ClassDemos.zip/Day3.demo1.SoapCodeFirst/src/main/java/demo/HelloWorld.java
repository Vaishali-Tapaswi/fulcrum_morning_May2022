package  demo;

import javax.jws.WebService;
import javax.xml.ws.Endpoint;

@WebService
public class HelloWorld {
    public String hello(String name){
        System.out.println("Hello invoked with " + name);
        return "Hello, " + name;
    }

    public int divide(int no1, int no2){
        System.out.println("Divide invoked with " + no1 + ", " + no2);
        return no1/no2;
    }

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8888/hello",new HelloWorld());
    }
}
