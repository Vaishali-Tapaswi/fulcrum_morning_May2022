/*
package demo;

import org.springframework.integration.core.MessageSelector;
import org.springframework.messaging.Message;
import java.io.File;

public class MyFilter implements MessageSelector {
    @Override
    public boolean accept(Message message) {
        System.out.println("Headers " + message.getHeaders());
        System.out.println("Payload " + message.getPayload());
        if (message.getPayload() instanceof File){
            System.out.println("Instance of File");
            if (((File) message.getPayload()).getName().startsWith("msg"))
                return false;
            else
                return true;
        }
        return false;
    }
}
 */
