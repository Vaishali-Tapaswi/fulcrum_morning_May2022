package params;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@RestController  // = @Controller+  @ResponseBody
@RequestMapping(value="/pv")
public class PathVariableDemo {

    @GetMapping(value="/hello/{nm}")
    public String hello( @PathVariable(name = "nm") String name){
        System.out.println("PathVariableDemo - hello invoked with " + name);
        return "Hiaaaa, " + name;
    }
    @GetMapping(value="/add/{n1}/{n2}")
    public String add(@PathVariable(name="n1") int no1,@PathVariable(name="n2") int no2){
        System.out.println("PathVariableDemo - add invoked with " + no1 + " , " + no2);
        return "Sum = " + (no1+no2);
    }
}
