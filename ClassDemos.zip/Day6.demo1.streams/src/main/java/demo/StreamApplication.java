package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamApplication {

	public static void main(String[] args) {

		SpringApplication.run(StreamApplication.class, args);
	}

}