package custom;


import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping(value = "/emp")
public class EmpController {
    private List<Emp> list =new ArrayList<>();
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity add(@RequestBody Emp e){
        System.out.println("EmpController add invoked with " + e);
        list.add(e);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Emp> list(){
        System.out.println("EmpController List invoked, current size =  "+ list.size());
        return list;
    }
    @DeleteMapping(value="/{eno}")
    public ResponseEntity delete(@PathVariable(name="eno") int empno){
        System.out.println("EmpController delete invoked with " + empno);
        for (Emp emp: list ) {
            if (emp.getEmpno() == empno){
                list.remove(emp);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            }
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity update(@RequestBody Emp modifiedemp){
        System.out.println("EmpController update invoked with " + modifiedemp);
        for (Emp emp: list ) {
            if (emp.getEmpno() == modifiedemp.getEmpno()){
                emp.setEname(modifiedemp.getEname());
                emp.setSalary(modifiedemp.getSalary());
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            }
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

}
