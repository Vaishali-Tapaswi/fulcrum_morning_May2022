package demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Receiver{

  @JmsListener(destination = "aamytopic", containerFactory = "myFactory" )
  public void receiveMessage(Email email) {
    System.out.println("Topic Received <" + email + ">");
  }

}