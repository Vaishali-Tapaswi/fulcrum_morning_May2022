package demo;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.FileWritingMessageHandler;

import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.io.File;

@Configuration
//@EnableIntegration
public class MyConfig {
    final String inputdir = "C:\\tt\\inputdir";
    final String outputdir1 = "C:\\tt\\ouputdir1";
    final String outputdir2 = "C:\\tt\\ouputdir2";

    @Bean
    public MessageChannel filechannel(){
    //   return new QueueChannel(4);
        return new PublishSubscribeChannel();
    }

    @Bean
    @InboundChannelAdapter(channel = "filechannel",poller = @Poller(fixedRate = "500"))
    public MessageSource<File> fileReading() {
        FileReadingMessageSource sourceReader = new FileReadingMessageSource();
        sourceReader.setDirectory(new File(inputdir));
         return sourceReader;
    }
    @Bean
    @ServiceActivator(inputChannel = "filechannel")
    public MessageHandler filewriting1() {
        FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(outputdir1));
        handler.setFileExistsMode(FileExistsMode.REPLACE);
        handler.setExpectReply(false);
        return handler;
    }
    @Bean
    @ServiceActivator(inputChannel = "filechannel")
    public MessageHandler filewriting2() {
        FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(outputdir2));
        handler.setFileExistsMode(FileExistsMode.REPLACE);
        handler.setExpectReply(false);
        return handler;
    }

}
