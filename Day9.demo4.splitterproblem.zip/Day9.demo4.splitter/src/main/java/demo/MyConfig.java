package demo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;

import org.springframework.integration.annotation.Splitter;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.FileWritingMessageHandler;

import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.integration.json.JsonToObjectTransformer;
import org.springframework.integration.stream.CharacterStreamWritingMessageHandler;
import org.springframework.integration.transformer.Transformer;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.support.MessageBuilder;

import java.io.File;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;

@Configuration
public class MyConfig {
    final String inputdir = "C:\\tt\\inputdir";
    final String outputdir1 = "C:\\tt\\outputdir1";

    public MessageChannel filechannel(){
        return new QueueChannel(5);
    }

    @Bean
    @InboundChannelAdapter(channel = "filechannel",poller = @Poller(fixedRate = "500"))
    public MessageSource<File> fileReading() {
        FileReadingMessageSource sourceReader = new FileReadingMessageSource();
        sourceReader.setDirectory(new File(inputdir));
        return sourceReader;
    }
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "filechannel", outputChannel = "stringoutput" )
    public Transformer tranform1() {
        return new FileToStringTransformer();
    }
    @Bean
    @org.springframework.integration.annotation.Transformer(inputChannel = "stringoutput", outputChannel = "jsonobject" )
    public Transformer tranform2() {
        return new JsonToObjectTransformer(ArrayList.class);
    }

    @Splitter(inputChannel = "jsonobject", outputChannel = "broken")
    public Collection<Emp> splitItem(ArrayList  list) {
        return list;
    }
    /// Convert Object to String and send string to handler

    @Bean
    @ServiceActivator(inputChannel = "broken")
    public MessageHandler handler() {
        System.out.println("Handler invoked ... ");
   FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(outputdir1));
        handler.setFileExistsMode(FileExistsMode.REPLACE);
        handler.setExpectReply(false);
        return handler;

   /*     CharacterStreamWritingMessageHandler handler = new CharacterStreamWritingMessageHandler(
                new OutputStreamWriter(System.err));
        handler.appendNewLine(true);
        return handler;
*/


    }

}
