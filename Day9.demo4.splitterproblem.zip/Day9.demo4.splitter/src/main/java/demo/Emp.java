
package demo;


public class Emp {

    protected int empno;
    protected String ename;
    protected double salary;

    public int getEmpno() {
        return empno;
    }

    public void setEmpno(int value) {
        this.empno = value;
    }

    public String getEname() {
        return ename;
    }

    /**
     * Sets the value of the ename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEname(String value) {
        this.ename = value;
    }

    /**
     * Gets the value of the salary property.
     * 
     */
    public double getSalary() {
        return salary;
    }

    /**
     * Sets the value of the salary property.
     * 
     */
    public void setSalary(double value) {
        this.salary = value;
    }

	@Override
	public String toString() {
		return "ttEmp [empno=" + empno + ", ename=" + ename + ", salary=" + salary + "]";
	}

}
