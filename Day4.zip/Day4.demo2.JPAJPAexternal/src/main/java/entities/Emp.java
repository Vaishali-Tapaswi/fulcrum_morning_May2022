package entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emptable")
public class Emp {
    @Id
   private  String empno;
   private  String ename;
    private   double salary ;// -> random number
    private   String project ;//-> proj1,proj2
    private   String department;//  (dept1,dept2,dept3

    @Override
    public String toString() {
        return "Emp{" +
                "empno='" + empno + '\'' +
                ", ename='" + ename + '\'' +
                ", salary=" + salary +
                ", project='" + project + '\'' +
                ", department='" + department + '\'' +
                '}';
    }

    public String getEmpno() {
        return empno;
    }

    public void setEmpno(String empno) {
        this.empno = empno;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
